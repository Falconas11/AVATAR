AVATAR v0.4.1-demo 头发修复补丁（适用于 v0.4.0-demo）

1. 在运行 AVATAR 的 PowerShell 窗口按 Ctrl+C 停止。
2. 解压此压缩包，把其中的 experiments 文件夹复制到原 AVATAR 根目录（能看到 data 的那层），选择替换已有文件。
3. 原环境中重新运行：
.\experiments\geometry_renderer\.venv\Scripts\python.exe -m experiments.geometry_renderer.launch
4. 浏览器刷新 http://127.0.0.1:8501，标题应为 AVATAR Local Aging v0.4.1。

仅更新 app.py、hair_layers.py；不删除照片、环境或模型，不需要重新安装依赖或下载模型。
本次移除亮区选白和随机发束，改为保守灰化、提亮上限与边界/异常亮区保护。灰发可能更轻微。
脸部自然度问题尚未解决。错误分割仍可能造成其他问题；可取消 Hair graying 保留原发。
未把用户上传的肖像纳入测试或发布包。
